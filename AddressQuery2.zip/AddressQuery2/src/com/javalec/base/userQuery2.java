package com.javalec.base;

import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class userQuery2 {

	private JFrame frame;
	private JComboBox cbSelection;
	private JTextField tfSelection;
	private JButton btnSearch;
	private JScrollPane scrollPane;
	private JTable inner_table;
	private JLabel lblNewLabel;
	private JLabel lblDlfma;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	private JLabel lblNewLabel_4;
	private JLabel lblNewLabel_5;
	private JTextField tfseqno;
	private JTextField tfName;
	private JTextField tftelno;
	private JTextField tfaddress;
	private JTextField tfemail;
	private JTextField tfrelation;
	private JButton btnok;
	private JRadioButton rdbtnNewRadioButton;
	private JRadioButton rdbtnNewRadioButton_1;
	private JRadioButton rdbtnNewRadioButton_1_1;
	private JRadioButton rdbtnNewRadioButton_1_2;

	//데이터 환경정의  
	
		private final String url_mysql = "jdbc:mysql://127.0.0.1/useraddress?serverTimezone=UTC&characterEncoding=utf8&useSSL=FALSE";
		private final String id_mysql = "root";
		private final String pw_mysql = "qwer1234";
	
	//Table 환경 정의 
		private final DefaultTableModel Outer_Table = new DefaultTableModel();
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					userQuery2 window = new userQuery2();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public userQuery2() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.addWindowListener(new WindowAdapter() {
			@Override
			public void windowOpened(WindowEvent e) {
				tableInit();
				searchAction();
			}
		});
		frame.setTitle("주소록관리");
		frame.setBounds(100, 100, 520, 558);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.getContentPane().add(getCbSelection());
		frame.getContentPane().add(getTfSelection());
		frame.getContentPane().add(getBtnSearch());
		frame.getContentPane().add(getScrollPane());
		frame.getContentPane().add(getLblNewLabel());
		frame.getContentPane().add(getLblDlfma());
		frame.getContentPane().add(getLblNewLabel_2());
		frame.getContentPane().add(getLblNewLabel_3());
		frame.getContentPane().add(getLblNewLabel_4());
		frame.getContentPane().add(getLblNewLabel_5());
		frame.getContentPane().add(getTfseqno());
		frame.getContentPane().add(getTfName());
		frame.getContentPane().add(getTftelno());
		frame.getContentPane().add(getTfaddress());
		frame.getContentPane().add(getTfemail());
		frame.getContentPane().add(getTfrelation());
		frame.getContentPane().add(getBtnok());
		frame.getContentPane().add(getRdbtnNewRadioButton());
		frame.getContentPane().add(getRdbtnNewRadioButton_1());
		frame.getContentPane().add(getRdbtnNewRadioButton_1_1());
		frame.getContentPane().add(getRdbtnNewRadioButton_1_2());
	}

	private JComboBox getCbSelection() {
		if (cbSelection == null) {
			cbSelection = new JComboBox();
			cbSelection.setModel(new DefaultComboBoxModel(new String[] {"이름", "번호", "관계"}));
			cbSelection.setBounds(12, 65, 51, 25);
		}
		return cbSelection;
	}
	private JTextField getTfSelection() {
		if (tfSelection == null) {
			tfSelection = new JTextField();
			tfSelection.setBounds(75, 67, 271, 21);
			tfSelection.setColumns(10);
		}
		return tfSelection;
	}
	private JButton getBtnSearch() {
		if (btnSearch == null) {
			btnSearch = new JButton("검색");
			btnSearch.setBounds(358, 66, 64, 23);
		}
		return btnSearch;
	}
	private JScrollPane getScrollPane() {
		if (scrollPane == null) {
			scrollPane = new JScrollPane();
			scrollPane.setBounds(12, 107, 480, 129);
			scrollPane.setViewportView(getInner_table());
		}
		return scrollPane;
	}
	private JTable getInner_table() {
		if (inner_table == null) {
			inner_table = new JTable();
		}
		return inner_table;
	}
	private JLabel getLblNewLabel() {
		if (lblNewLabel == null) {
			lblNewLabel = new JLabel("Sequence No :");
			lblNewLabel.setBounds(12, 263, 95, 15);
		}
		return lblNewLabel;
	}
	private JLabel getLblDlfma() {
		if (lblDlfma == null) {
			lblDlfma = new JLabel("이름");
			lblDlfma.setBounds(12, 298, 57, 15);
		}
		return lblDlfma;
	}
	private JLabel getLblNewLabel_2() {
		if (lblNewLabel_2 == null) {
			lblNewLabel_2 = new JLabel("번호");
			lblNewLabel_2.setBounds(12, 339, 57, 15);
		}
		return lblNewLabel_2;
	}
	private JLabel getLblNewLabel_3() {
		if (lblNewLabel_3 == null) {
			lblNewLabel_3 = new JLabel("주소");
			lblNewLabel_3.setBounds(12, 377, 57, 15);
		}
		return lblNewLabel_3;
	}
	private JLabel getLblNewLabel_4() {
		if (lblNewLabel_4 == null) {
			lblNewLabel_4 = new JLabel("전자우편주소");
			lblNewLabel_4.setBounds(12, 421, 77, 15);
		}
		return lblNewLabel_4;
	}
	private JLabel getLblNewLabel_5() {
		if (lblNewLabel_5 == null) {
			lblNewLabel_5 = new JLabel("관계");
			lblNewLabel_5.setBounds(12, 465, 57, 15);
		}
		return lblNewLabel_5;
	}
	private JTextField getTfseqno() {
		if (tfseqno == null) {
			tfseqno = new JTextField();
			tfseqno.setBounds(119, 260, 40, 21);
			tfseqno.setColumns(10);
		}
		return tfseqno;
	}
	private JTextField getTfName() {
		if (tfName == null) {
			tfName = new JTextField();
			tfName.setColumns(10);
			tfName.setBounds(119, 295, 89, 21);
		}
		return tfName;
	}
	private JTextField getTftelno() {
		if (tftelno == null) {
			tftelno = new JTextField();
			tftelno.setColumns(10);
			tftelno.setBounds(119, 336, 132, 21);
		}
		return tftelno;
	}
	private JTextField getTfaddress() {
		if (tfaddress == null) {
			tfaddress = new JTextField();
			tfaddress.setColumns(10);
			tfaddress.setBounds(119, 374, 265, 21);
		}
		return tfaddress;
	}
	private JTextField getTfemail() {
		if (tfemail == null) {
			tfemail = new JTextField();
			tfemail.setColumns(10);
			tfemail.setBounds(119, 418, 227, 21);
		}
		return tfemail;
	}
	private JTextField getTfrelation() {
		if (tfrelation == null) {
			tfrelation = new JTextField();
			tfrelation.setColumns(10);
			tfrelation.setBounds(119, 462, 116, 21);
		}
		return tfrelation;
	}
	private JButton getBtnok() {
		if (btnok == null) {
			btnok = new JButton("OK");
			btnok.setBounds(325, 486, 97, 23);
		}
		return btnok;
	}
	private JRadioButton getRdbtnNewRadioButton() {
		if (rdbtnNewRadioButton == null) {
			rdbtnNewRadioButton = new JRadioButton("입력");
			rdbtnNewRadioButton.setBounds(8, 18, 64, 23);
		}
		return rdbtnNewRadioButton;
	}
	private JRadioButton getRdbtnNewRadioButton_1() {
		if (rdbtnNewRadioButton_1 == null) {
			rdbtnNewRadioButton_1 = new JRadioButton("수정");
			rdbtnNewRadioButton_1.setBounds(75, 18, 64, 23);
		}
		return rdbtnNewRadioButton_1;
	}
	private JRadioButton getRdbtnNewRadioButton_1_1() {
		if (rdbtnNewRadioButton_1_1 == null) {
			rdbtnNewRadioButton_1_1 = new JRadioButton("삭제");
			rdbtnNewRadioButton_1_1.setBounds(144, 18, 64, 23);
		}
		return rdbtnNewRadioButton_1_1;
	}
	private JRadioButton getRdbtnNewRadioButton_1_2() {
		if (rdbtnNewRadioButton_1_2 == null) {
			rdbtnNewRadioButton_1_2 = new JRadioButton("검색");
			rdbtnNewRadioButton_1_2.setBounds(212, 18, 64, 23);
		}
		return rdbtnNewRadioButton_1_2;
	}
	
	
	//화면 초기화 ======================
	
	private void tableInit() {
		Outer_Table.addColumn("Index");						// 아웃터 테이블에 항목 넣기
		Outer_Table.addColumn("Name");
		Outer_Table.addColumn("PhoneNumber");
		Outer_Table.addColumn("relation");
		Outer_Table.setColumnCount(4); //테이블에 보여줄 게 4개다 
		
		// 데이터가 혹시 화면에 있으면 지워준다. 프로그램 시작 
		
		int i = Outer_Table.getRowCount();
		for(int  j= 0; j<i; j++) {
			Outer_Table.removeRow(0);
		}
		
		inner_table.setAutoResizeMode(inner_table.AUTO_RESIZE_OFF);
		
		int vColIndex =0;
		TableColumn col = inner_table.getColumnModel().getColumn(vColIndex);
		int width = 30;
		col.setPreferredWidth(width);
		
		vColIndex =1;
		col = inner_table.getColumnModel().getColumn(vColIndex);
		width = 100;
		col.setPreferredWidth(width);
		
		vColIndex =2;
		col = inner_table.getColumnModel().getColumn(vColIndex);
		width = 100;
		col.setPreferredWidth(width);
		
		vColIndex =3;
		col = inner_table.getColumnModel().getColumn(vColIndex);
		width = 200;
		col.setPreferredWidth(width);

	}
	
	//===============데이터불러와서 입력하기
	
	private void searchAction() {
		
		String query = "select seqno, name, telno, relation from userinfo ";
		PreparedStatement ps = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn_mysql = DriverManager.getConnection(url_mysql, id_mysql, pw_mysql);
			Statement stmt_mysql = conn_mysql.createStatement();
			
			ResultSet rs = stmt_mysql.executeQuery(query);
			
			while(rs.next()) {
				
				String[] qTxt = {rs.getString(1), rs.getString(2), rs.getString(3),rs.getString(4)};
				Outer_Table.addRow(qTxt);
			}
			
			conn_mysql.close();
			
			} catch (Exception e) {
				e.printStackTrace();
		}
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}//=========================
